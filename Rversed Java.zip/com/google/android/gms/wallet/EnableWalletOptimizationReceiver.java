package com.google.android.gms.wallet;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public final class EnableWalletOptimizationReceiver extends BroadcastReceiver {
    public final void onReceive(Context context, Intent intent) {
    }
}
