package com.google.android.gms.internal;

public final class C {
    public static Object Code(Object obj) {
        if (obj != null) {
            return obj;
        }
        throw new NullPointerException("null reference");
    }
}
