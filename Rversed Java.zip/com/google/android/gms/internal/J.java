package com.google.android.gms.internal;

public final class J {
    public static B Code(Object obj) {
        return new B(obj, (byte) 0);
    }
}
