package com.google.android.gms.ads.identifier;

public final class Code {
    private final String Code;

    Code(String str) {
        this.Code = str;
    }

    public final String Code() {
        return this.Code;
    }
}
