package com.google.android.apps.analytics;

public final class Code {
    public Code() {
        try {
            Class.forName("v");
        } catch (ClassNotFoundException e) {
        }
    }
}
