package com.google.android.apps.analytics;

interface B {
    void Code();

    void Code(C c);

    void Code(f[] fVarArr);
}
