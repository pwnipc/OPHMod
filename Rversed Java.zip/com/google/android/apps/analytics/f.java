package com.google.android.apps.analytics;

public final class f {
    final String Code;
    final long I;

    f(String str, long j) {
        this.Code = str;
        this.I = j;
    }
}
