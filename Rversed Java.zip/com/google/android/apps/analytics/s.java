package com.google.android.apps.analytics;

final class s {
    final /* synthetic */ n Code;

    private s(n nVar) {
        this.Code = nVar;
    }

    /* synthetic */ s(n nVar, byte b) {
        this(nVar);
    }

    public final void Code() {
        int unused = this.Code.B = 1;
    }

    public final void I() {
        f Code2;
        if (this.Code.a != null && (Code2 = this.Code.a.Code()) != null) {
            C a = this.Code.b;
            a.Code.b.Code(Code2.I);
        }
    }
}
