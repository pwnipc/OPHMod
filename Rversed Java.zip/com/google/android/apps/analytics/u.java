package com.google.android.apps.analytics;

public final class u {
    private final double B;
    private final String Code;
    private final String I;
    private final double J;
    private final double Z;

    private u(v vVar) {
        this.Code = vVar.Code;
        this.Z = vVar.Z;
        this.I = vVar.I;
        this.J = vVar.J;
        this.B = vVar.B;
    }

    /* synthetic */ u(v vVar, byte b) {
        this(vVar);
    }

    /* access modifiers changed from: package-private */
    public final double B() {
        return this.B;
    }

    /* access modifiers changed from: package-private */
    public final String Code() {
        return this.Code;
    }

    /* access modifiers changed from: package-private */
    public final String I() {
        return this.I;
    }

    /* access modifiers changed from: package-private */
    public final double J() {
        return this.J;
    }

    /* access modifiers changed from: package-private */
    public final double Z() {
        return this.Z;
    }
}
