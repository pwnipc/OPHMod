package com.google.android.apps.analytics;

public final class k {
    private final double B;
    private final long C;
    private final String Code;
    private final String I;
    private final String J;
    private final String Z;

    private k(l lVar) {
        this.Code = lVar.Code;
        this.I = lVar.I;
        this.B = lVar.Z;
        this.C = lVar.J;
        this.Z = lVar.B;
        this.J = lVar.C;
    }

    /* synthetic */ k(l lVar, byte b) {
        this(lVar);
    }

    /* access modifiers changed from: package-private */
    public final double B() {
        return this.B;
    }

    /* access modifiers changed from: package-private */
    public final long C() {
        return this.C;
    }

    /* access modifiers changed from: package-private */
    public final String Code() {
        return this.Code;
    }

    /* access modifiers changed from: package-private */
    public final String I() {
        return this.I;
    }

    /* access modifiers changed from: package-private */
    public final String J() {
        return this.J;
    }

    /* access modifiers changed from: package-private */
    public final String Z() {
        return this.Z;
    }
}
