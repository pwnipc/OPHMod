package com.google.android.apps.analytics;

public final class C {
    final /* synthetic */ d Code;

    C(d dVar) {
        this.Code = dVar;
    }
}
