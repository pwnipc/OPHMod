package com.google.android.apps.analytics;

final class t {
    private final String Code;
    private final long I;
    private final int J;
    private final int Z;

    t(String str, long j, int i, int i2) {
        this.Code = str;
        this.I = j;
        this.Z = i;
        this.J = i2;
    }

    /* access modifiers changed from: package-private */
    public final String Code() {
        return this.Code;
    }

    /* access modifiers changed from: package-private */
    public final long I() {
        return this.I;
    }

    /* access modifiers changed from: package-private */
    public final int J() {
        return this.J;
    }

    /* access modifiers changed from: package-private */
    public final int Z() {
        return this.Z;
    }
}
