package com.google.android.apps.analytics;

interface h {
    void Code(long j);

    boolean Code(String str);

    f[] Code();

    int I();

    void Z();
}
