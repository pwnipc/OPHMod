package com.google.android.apps.analytics;

final class e implements Runnable {
    private /* synthetic */ C Code;

    e(C c) {
        this.Code = c;
    }

    public final void run() {
        this.Code.Code.Z();
    }
}
