package com.google.analytics.tracking.android;

import java.util.List;
import java.util.Map;

/* compiled from: Source */
final class w {
    private final Map Code;
    private final long I;
    private final List J;
    private final String Z;

    public w(Map map, long j, String str, List list) {
        this.Code = map;
        this.I = j;
        this.Z = str;
        this.J = list;
    }

    public final Map Code() {
        return this.Code;
    }

    public final long I() {
        return this.I;
    }

    public final String Z() {
        return this.Z;
    }

    public final List J() {
        return this.J;
    }
}
