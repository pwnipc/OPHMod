package com.google.analytics.tracking.android;

/* compiled from: Source */
interface k {
    long Code();
}
