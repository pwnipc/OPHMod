package com.google.analytics.tracking.android;

/* compiled from: Source */
public interface a {
    void Code(int i);
}
