package com.google.analytics.tracking.android;

import com.google.analytics.tracking.android.g;
import java.util.Map;
import java.util.concurrent.LinkedBlockingQueue;

/* compiled from: Source */
interface f {
    void Code();

    void Code(g.Code code);

    void Code(g.I i);

    void Code(Map map);

    void Code(boolean z);

    LinkedBlockingQueue I();

    Thread Z();
}
