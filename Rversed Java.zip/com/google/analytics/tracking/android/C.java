package com.google.analytics.tracking.android;

/* compiled from: Source */
public interface C {
    void Code();

    void I();
}
