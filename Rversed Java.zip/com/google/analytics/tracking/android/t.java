package com.google.analytics.tracking.android;

/* compiled from: Source */
enum t {
    CONNECTING,
    CONNECTED_SERVICE,
    CONNECTED_LOCAL,
    BLOCKED,
    PENDING_CONNECTION,
    PENDING_DISCONNECT,
    DISCONNECTED
}
