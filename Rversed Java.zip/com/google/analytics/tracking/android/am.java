package com.google.analytics.tracking.android;

/* compiled from: Source */
public interface am {
    void Code(int i);

    void Code(boolean z);

    void Z();
}
