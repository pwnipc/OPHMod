package com.google.analytics.tracking.android;

import java.util.TimerTask;

/* compiled from: Source */
final class o extends TimerTask {
    private /* synthetic */ m Code;

    private o(m mVar) {
        this.Code = mVar;
    }

    /* synthetic */ o(m mVar, byte b) {
        this(mVar);
    }

    public final void run() {
        boolean unused = this.Code.r = false;
    }
}
