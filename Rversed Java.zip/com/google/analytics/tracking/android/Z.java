package com.google.analytics.tracking.android;

import java.util.List;
import java.util.Map;

/* compiled from: Source */
interface Z {
    void Code();

    void Code(Map map, long j, String str, List list);

    void I();

    void Z();
}
