package com.google.analytics.tracking.android;

/* compiled from: Source */
final class ac {
    private String Code = null;
    private final long I;
    private String J;
    private final long Z;

    /* access modifiers changed from: package-private */
    public final String Code() {
        return this.Code;
    }

    /* access modifiers changed from: package-private */
    public final void Code(String str) {
        this.Code = str;
    }

    /* access modifiers changed from: package-private */
    public final long I() {
        return this.I;
    }

    /* access modifiers changed from: package-private */
    public final long Z() {
        return this.Z;
    }

    ac(long j, long j2) {
        this.I = j;
        this.Z = j2;
    }

    /* access modifiers changed from: package-private */
    public final String J() {
        return this.J;
    }

    /* access modifiers changed from: package-private */
    public final void I(String str) {
        this.J = str;
    }
}
