package com.google.analytics.tracking.android;

import java.util.Map;

/* compiled from: Source */
interface aq {
    void Code(Map map);
}
