package com.google.analytics.tracking.android;

import java.util.List;
import java.util.Map;

/* compiled from: Source */
interface an {
    void B();

    void Code(Map map, long j, String str, List list);

    void J();

    void Z();
}
