package com.google.analytics.tracking.android;

import java.util.Collection;
import java.util.Map;

/* compiled from: Source */
interface d {
    void Code();

    void Code(Map map, long j, String str, Collection collection);

    void I();
}
