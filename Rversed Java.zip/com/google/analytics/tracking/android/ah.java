package com.google.analytics.tracking.android;

/* compiled from: Source */
public interface ah {
    String Code(String str);
}
