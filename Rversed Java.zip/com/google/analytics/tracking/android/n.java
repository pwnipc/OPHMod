package com.google.analytics.tracking.android;

import java.util.HashMap;
import java.util.Map;

/* compiled from: Source */
final class n extends ao {
    n() {
    }

    public final void Code() {
    }

    public final void Code(String str) {
    }

    public final void I(String str) {
    }

    public final void Z(String str) {
    }

    public final void Code(String str, String str2, String str3, Long l) {
    }

    public final void J(String str) {
    }

    public final void Code(String str, long j, String str2, String str3) {
    }

    public final void Code(boolean z) {
    }

    public final void Code(double d) {
    }

    public final Map I(String str, String str2, String str3, Long l) {
        return new HashMap();
    }

    public final Map B(String str) {
        return new HashMap();
    }

    public final Map I(String str, long j, String str2, String str3) {
        return new HashMap();
    }

    public final void Code(int i, String str) {
    }

    public final void Code(int i, Long l) {
    }
}
