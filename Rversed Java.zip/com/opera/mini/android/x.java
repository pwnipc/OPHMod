package com.opera.mini.android;

import android.opengl.GLSurfaceView;

/* compiled from: Source */
public class x {
    @DontOptimize
    public static void Code(GLSurfaceView gLSurfaceView, boolean z) {
        gLSurfaceView.setPreserveEGLContextOnPause(z);
    }
}
