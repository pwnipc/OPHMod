package com.opera.mini.android;

/* compiled from: Source */
public class az implements Runnable {
    final /* synthetic */ ax Code;

    public az(ax axVar) {
        this.Code = axVar;
    }

    public void run() {
        this.Code.I.Code();
    }
}
