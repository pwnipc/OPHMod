package com.opera.mini.android;

import android.graphics.Bitmap;

/* compiled from: Source */
public final class e implements d {
    public final boolean Code() {
        return true;
    }

    public final void I() {
    }

    public final void Code(Bitmap bitmap) {
    }
}
