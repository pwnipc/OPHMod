package com.opera.mini.android;

import android.content.Context;

/* compiled from: Source */
public final class bg {
    private final Context Code;

    /* synthetic */ bg(Context context, byte b) {
        this(context);
    }

    private bg(Context context) {
        this.Code = context;
    }

    public final void Code(String str) {
        if (str != null) {
            new bi(this.Code);
            String unused = bf.I = bf.I(this.Code);
            ai.Code(new bk(str), new Void[0]);
        }
    }
}
