package com.opera.mini.android;

/* compiled from: Source */
public @interface DontOptimize {
}
