package com.opera.mini.android;

/* compiled from: Source */
class aw implements Runnable {
    av Code;
    final /* synthetic */ av I;

    public aw(av avVar, av avVar2) {
        this.I = avVar;
        this.Code = avVar2;
    }

    public void run() {
        this.Code.c();
    }
}
