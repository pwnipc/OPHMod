package com.opera.mini.android;

/* compiled from: Source */
public final class v {
}
