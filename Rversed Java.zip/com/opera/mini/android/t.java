package com.opera.mini.android;

/* compiled from: Source */
public enum t {
    SUCCESS,
    FAILURE,
    NO_AVAILABLE_DISK_SPACE
}
