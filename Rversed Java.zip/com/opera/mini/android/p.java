package com.opera.mini.android;

import com.opera.mini.android.events.ActivityResumeEvent;

/* compiled from: Source */
final class p {
    p() {
    }

    @dm
    public final void onActivityResumed(ActivityResumeEvent activityResumeEvent) {
        String unused = o.o = null;
    }
}
