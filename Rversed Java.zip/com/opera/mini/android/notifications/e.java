package com.opera.mini.android.notifications;

/* compiled from: Source */
final class e {
    e() {
    }
}
