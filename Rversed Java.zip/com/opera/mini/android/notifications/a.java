package com.opera.mini.android.notifications;

/* compiled from: Source */
public final class a {
    public byte Code;
    public byte I;
}
