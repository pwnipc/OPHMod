package com.opera.mini.android;

import android.graphics.Bitmap;

/* compiled from: Source */
public class g implements d {
    private a Code;
    private Bitmap I;

    public native boolean Code();

    public native void I();

    public g(a aVar, Bitmap bitmap) {
        this.Code = aVar;
        this.I = bitmap;
    }

    public final void Code(Bitmap bitmap) {
    }
}
