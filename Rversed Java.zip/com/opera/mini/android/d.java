package com.opera.mini.android;

import android.graphics.Bitmap;

/* compiled from: Source */
public interface d {
    void Code(Bitmap bitmap);

    boolean Code();

    void I();
}
