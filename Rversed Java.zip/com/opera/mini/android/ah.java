package com.opera.mini.android;

/* compiled from: Source */
final class ah extends RuntimeException {
    ah(String str) {
        super(str);
    }
}
