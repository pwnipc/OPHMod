package com.opera.mini.android.events;

import android.app.Activity;

/* compiled from: Source */
public class ActivityResumeEvent {
    public Activity Code;

    public ActivityResumeEvent(Activity activity) {
        this.Code = activity;
    }
}
