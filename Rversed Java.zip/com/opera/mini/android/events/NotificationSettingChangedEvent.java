package com.opera.mini.android.events;

/* compiled from: Source */
public class NotificationSettingChangedEvent {
    public boolean Code;

    public NotificationSettingChangedEvent(boolean z) {
        this.Code = z;
    }
}
