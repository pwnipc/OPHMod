package com.opera.mini.android.events;

/* compiled from: Source */
public class BreamInitializedEvent {
}
