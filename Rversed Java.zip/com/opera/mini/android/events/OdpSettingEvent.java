package com.opera.mini.android.events;

/* compiled from: Source */
public class OdpSettingEvent {
    public boolean Code;

    public OdpSettingEvent(boolean z) {
        this.Code = z;
    }
}
