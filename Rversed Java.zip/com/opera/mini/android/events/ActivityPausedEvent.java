package com.opera.mini.android.events;

import android.app.Activity;

/* compiled from: Source */
public class ActivityPausedEvent {
    public Activity Code;

    public ActivityPausedEvent(Activity activity) {
        this.Code = activity;
    }
}
