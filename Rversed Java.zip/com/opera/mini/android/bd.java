package com.opera.mini.android;

import android.view.View;

/* compiled from: Source */
public interface bd {
    void C();

    View Code();

    void Code(int i, int i2, int i3, int i4);

    bd I();

    void J();

    void Z();

    void a();

    boolean b();

    void onPause();

    void onResume();

    void onSizeChanged(int i, int i2, int i3, int i4);
}
