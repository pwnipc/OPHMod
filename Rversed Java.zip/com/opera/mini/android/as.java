package com.opera.mini.android;

/* compiled from: Source */
enum as {
    USER,
    SESSION,
    HIT
}
