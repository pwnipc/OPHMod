package com.begal.appclone.classes;

public final class R {

    public static final class id {
        public static final int text = 2130771968;
    }

    public static final class layout {

        /* renamed from: main */
        public static final int app_icon = 2130837504;
    }

    public static final class mipmap {

        /* renamed from: ic_launcher */
        public static final int main = 2130903040;
    }

    public static final class string {

        /* renamed from: app_name */
        public static final int STR_DISCOVER_NOTIFICATION = 2130968576;
    }

    public static final class xml {

        /* renamed from: device_admin */
        public static final int ga_autoActivityTracking = 2131034112;
    }
}
