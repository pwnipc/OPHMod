package com.begal.appclone.classes.freeform;

public class FreeFormWindowActivity2 extends FreeFormWindowActivity {
}
