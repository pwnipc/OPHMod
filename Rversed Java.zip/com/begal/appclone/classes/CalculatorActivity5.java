package com.begal.appclone.classes;

import android.annotation.SuppressLint;

@SuppressLint({"Registered"})
public class CalculatorActivity5 extends CalculatorActivity {
}
