package com.begal.appclone.classes;

import android.app.Activity;
import android.os.Bundle;
import com.opera.mini.h4lflif4.R;

public class DummyActivity extends Activity {
    /* access modifiers changed from: protected */
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.drawable.app_icon);
    }
}
