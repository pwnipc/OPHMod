package defpackage;

/* renamed from: bn  reason: default package */
/* compiled from: Source */
public interface bn {
    boolean B(String str);

    int[] B();

    boolean C(String str);

    int Code(byte[] bArr, String str);

    bm Code(String str, boolean z, int i);

    void Code();

    boolean Code(String str);

    long I(String str);

    String I();

    String J();

    byte[] J(String str);

    long Z(String str);

    String Z();
}
