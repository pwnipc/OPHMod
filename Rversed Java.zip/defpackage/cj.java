package defpackage;

/* renamed from: cj  reason: default package */
/* compiled from: Source */
public final class cj {
    public static String Code;
    public static String I;
    public static byte[] Z;
}
