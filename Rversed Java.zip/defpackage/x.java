package defpackage;

import com.opera.mini.h4lflif4.R;

/* renamed from: x  reason: default package */
/* compiled from: Source */
public final class x {
    public static int B = R.bool.ga_anonymizeIp;
    public static int C = 2131034114;
    public static int Code = 2131034118;
    public static int I = 2131034117;
    public static int J = 2131034115;
    public static int Z = 2131034116;
    public static int a = R.bool.ga_autoActivityTracking;
    public static int b = 2131034124;
    public static int c = 2131034123;
    public static int d = 2131034122;
    public static int e = 2131034121;
    public static int f = 2131034125;
    public static int g = 2131034128;
    public static int h = 2131034127;
    public static int i = 2131034126;
    public static int j = 2131034129;
    public static int k = 2131034120;
    public static int l = 2131034119;
}
