package defpackage;

import com.google.android.gms.internal.Code;

/* renamed from: y  reason: default package */
public final class y {
    public static final String Code = Code.Code("emulator");
}
