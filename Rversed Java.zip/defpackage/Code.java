package defpackage;

/* renamed from: Code  reason: default package */
/* compiled from: Source */
interface Code {
    void Code(l lVar);
}
