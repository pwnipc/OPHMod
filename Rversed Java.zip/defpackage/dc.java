package defpackage;

/* renamed from: dc  reason: default package */
/* compiled from: Source */
public interface dc {
    int Code();

    boolean Code(byte[] bArr, int i, int i2);

    int I();
}
