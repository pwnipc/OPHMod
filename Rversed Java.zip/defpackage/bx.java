package defpackage;

import java.util.Vector;

/* renamed from: bx  reason: default package */
/* compiled from: Source */
public final class bx {
    public static Vector Code;
}
