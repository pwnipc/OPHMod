package defpackage;

import java.io.InputStream;

/* renamed from: aq  reason: default package */
/* compiled from: Source */
public interface aq {
    void B();

    void C();

    void Code();

    void Code(int i);

    void Code(int i, int i2);

    void Code(Object obj);

    void Code(boolean z);

    boolean Code(String str);

    byte[] Code(int i, int i2, int i3, int i4, int i5);

    InputStream I(String str);

    void I(int i);

    boolean I();

    void J();

    void Z();

    void a();

    void b();

    boolean c();

    void d();
}
