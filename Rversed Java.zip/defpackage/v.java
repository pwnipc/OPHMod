package defpackage;

@Deprecated
/* renamed from: v  reason: default package */
public final class v {
    static {
        String str = y.Code;
    }

    private v() {
    }
}
