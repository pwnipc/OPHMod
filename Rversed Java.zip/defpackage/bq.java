package defpackage;

/* renamed from: bq  reason: default package */
/* compiled from: Source */
public interface bq {
    int Code(int i);

    bp Code(int i, int i2);

    bp Code(int i, int i2, int i3);
}
