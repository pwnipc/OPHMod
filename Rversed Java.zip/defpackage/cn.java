package defpackage;

/* renamed from: cn  reason: default package */
/* compiled from: Source */
public abstract class cn {
    public static cn Code;

    public abstract int Code(String str, byte[] bArr);

    public abstract void Code(String str, int i, byte[] bArr);

    public abstract void Code(String str, String str2, byte[] bArr, int i);

    public abstract boolean Code(String str);

    public abstract boolean Code(String str, String str2);

    public abstract byte[] Code(String str, int i);

    public abstract void I(String str, int i);

    public abstract void I(String str, String str2);

    public abstract byte[] I(String str);

    public abstract ax J(String str, String str2);

    public abstract void Z(String str);

    public abstract byte[] Z(String str, String str2);
}
