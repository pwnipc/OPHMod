package defpackage;

/* renamed from: g  reason: default package */
/* compiled from: Source */
final class g {
}
