package defpackage;

/* renamed from: ca  reason: default package */
/* compiled from: Source */
public abstract class ca {
    public static int Code() {
        switch (db.f) {
            case -9:
            case -8:
            case -6:
            case -2:
                return 35;
            case -5:
                return 42;
            default:
                return 48;
        }
    }
}
