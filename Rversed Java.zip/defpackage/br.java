package defpackage;

/* renamed from: br  reason: default package */
/* compiled from: Source */
public interface br {
    int Code();

    void Code(char c, int i, int i2, bp bpVar, int i3);

    void Code(int i, int i2, int i3, int i4);

    void Code(int i, int i2, int i3, int i4, int i5);

    void Code(int i, int i2, int i3, int i4, int i5, int i6);

    void Code(int i, int i2, int i3, int i4, int i5, int i6, int i7);

    void Code(int i, char[] cArr, int i2, int i3, int i4, int i5, int i6, boolean z, int i7, int i8, int i9);

    void Code(bu buVar, int i, int i2);

    void Code(bu buVar, int i, int i2, int i3, int i4, int i5, int i6);

    void Code(bu buVar, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8);

    void Code(bu buVar, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9);

    void Code(bu buVar, int i, int i2, int i3, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11);

    void Code(bu buVar, int i, int i2, int i3, int i4, boolean z);

    void Code(String str, int i, int i2, bp bpVar, int i3);

    void Code(char[] cArr, int i, int i2, int i3, int i4, bp bpVar, int i5);

    void Code(int[] iArr, int i, int i2, int i3, int i4, int i5, int i6, boolean z);

    int I();

    void I(int i, int i2, int i3, int i4);

    void I(int i, int i2, int i3, int i4, int i5);

    void I(bu buVar, int i, int i2, int i3, int i4, int i5, int i6);

    int J();

    void J(int i, int i2, int i3, int i4, int i5);

    int Z();

    void Z(int i, int i2, int i3, int i4, int i5);
}
