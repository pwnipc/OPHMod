package defpackage;

import java.io.DataInputStream;
import java.io.DataOutputStream;

/* renamed from: bc  reason: default package */
/* compiled from: Source */
public interface bc {
    long B();

    String Code(String str);

    void Code();

    void Code(String str, String str2);

    DataOutputStream I();

    int J();

    DataInputStream Z();
}
