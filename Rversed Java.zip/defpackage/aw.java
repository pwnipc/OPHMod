package defpackage;

/* renamed from: aw  reason: default package */
/* compiled from: Source */
class aw {
    int B;
    int C;
    int Code;
    int I;
    int J;
    int Z;

    aw(int i, int i2, int i3, int i4, int i5, int i6) {
        this.Code = i;
        this.I = i2;
        this.Z = i3;
        this.J = i4;
        this.B = i5;
        this.C = i6;
    }
}
