package defpackage;

import android.app.Notification;

/* renamed from: f  reason: default package */
/* compiled from: Source */
class f extends e {
    f() {
    }

    public Notification Code(Z z) {
        p pVar = new p(z.Code, z.C, z.I, z.Z, z.J);
        I.Code(pVar, z.B);
        I.Code();
        return pVar.Code();
    }
}
