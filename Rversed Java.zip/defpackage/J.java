package defpackage;

import android.app.Notification;

/* renamed from: J  reason: default package */
/* compiled from: Source */
class J {
    J() {
    }

    public Notification Code(Z z) {
        Notification notification = z.C;
        notification.setLatestEventInfo(z.Code, z.I, z.Z, z.J);
        return notification;
    }
}
