package defpackage;

/* renamed from: ap  reason: default package */
/* compiled from: Source */
public class ap extends ao {
    public static native int B(byte[] bArr, int i);

    public static native int Code(byte[] bArr, int i, char[] cArr, int i2, int i3);

    public static native int I(int i);
}
