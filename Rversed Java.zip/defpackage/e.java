package defpackage;

import android.app.Notification;

/* renamed from: e  reason: default package */
/* compiled from: Source */
class e extends J {
    e() {
    }

    public Notification Code(Z z) {
        n nVar = new n(z.Code, z.C, z.I, z.Z, z.J);
        I.Code(nVar, z.B);
        I.Code();
        return nVar.Code();
    }
}
