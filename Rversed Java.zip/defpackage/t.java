package defpackage;

import android.os.Bundle;

/* renamed from: t  reason: default package */
/* compiled from: Source */
public abstract class t {
    /* access modifiers changed from: protected */
    public abstract Bundle B();

    /* access modifiers changed from: protected */
    public abstract String Code();

    /* access modifiers changed from: protected */
    public abstract CharSequence I();

    /* access modifiers changed from: protected */
    public abstract boolean J();

    /* access modifiers changed from: protected */
    public abstract CharSequence[] Z();
}
