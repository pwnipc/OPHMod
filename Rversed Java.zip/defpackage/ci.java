package defpackage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.InputStream;
import java.util.Map;
import java.util.Vector;

/* renamed from: ci  reason: default package */
/* compiled from: Source */
public interface ci {
    void A();

    int B();

    void B(int i);

    void B(String str);

    int C();

    int C(int i);

    bc Code(String str, String str2);

    bc Code(String str, String str2, String str3);

    cs Code(int i, byte b, boolean z, boolean z2);

    Object Code(int i, int i2, String str, String str2, int i3, String str3, String str4, int i4, int i5, int i6, int i7, int i8, int i9, int i10, int i11, bp bpVar, int i12, int i13, int i14);

    String Code(String str);

    String Code(String[] strArr);

    void Code();

    void Code(int i, int i2);

    void Code(int i, int i2, int i3, int i4);

    void Code(int i, int i2, String str, String str2);

    void Code(DataInputStream dataInputStream, int i);

    void Code(DataOutputStream dataOutputStream);

    void Code(Object obj);

    void Code(Object obj, int i, int i2, int i3, int i4, int i5, int i6);

    void Code(Object obj, String str);

    void Code(Object obj, String str, int i, boolean z);

    void Code(Map map);

    void Code(boolean z);

    boolean Code(int i);

    boolean D();

    boolean E();

    boolean F();

    int G();

    int H();

    int I(String str, String str2);

    String I(Object obj);

    String I(String[] strArr);

    void I(int i);

    void I(int i, int i2);

    void I(boolean z);

    boolean I();

    boolean I(String str);

    int J();

    void J(String str, String str2);

    void J(boolean z);

    boolean J(int i);

    boolean J(String str);

    boolean K();

    boolean L();

    int M();

    int N();

    int O();

    int P();

    void Q();

    void R();

    boolean S();

    String T();

    String U();

    String V();

    void W();

    void X();

    boolean Y();

    InputStream Z(String str);

    Vector Z(int i);

    void Z(Object obj);

    void Z(String str, String str2);

    void Z(boolean z);

    boolean Z();

    int a();

    boolean a(int i);

    boolean aa();

    void ab();

    String ac();

    void ad();

    boolean ae();

    byte[] af();

    byte[] ag();

    bu ah();

    bu ai();

    bu aj();

    bu ak();

    boolean al();

    String am();

    int b();

    int c();

    boolean d();

    void e();

    boolean f();

    boolean g();

    int h();

    void i();

    int j();

    boolean k();

    bk l();

    boolean m();

    void n();

    void o();

    boolean p();

    bv q();

    bv r();

    bq s();

    boolean t();

    int u();

    int v();

    bb w();

    by x();

    void y();

    void z();
}
