package defpackage;

/* renamed from: av  reason: default package */
/* compiled from: Source */
final class av extends aw {
    av(int i) {
        super(0, 0, 0, i, 1, 0);
    }
}
