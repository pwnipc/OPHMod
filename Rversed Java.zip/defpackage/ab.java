package defpackage;

import android.os.IInterface;
import java.util.List;
import java.util.Map;

/* renamed from: ab  reason: default package */
/* compiled from: Source */
public interface ab extends IInterface {
    void Code();

    void Code(Map map, long j, String str, List list);
}
