package defpackage;

/* renamed from: dg  reason: default package */
/* compiled from: Source */
final class dg {
    final Object Code;
    final di I;

    public dg(Object obj, di diVar) {
        this.Code = obj;
        this.I = diVar;
    }
}
