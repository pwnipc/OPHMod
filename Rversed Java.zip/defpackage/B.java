package defpackage;

import android.app.Notification;

/* renamed from: B  reason: default package */
/* compiled from: Source */
final class B extends f {
    B() {
    }

    public final Notification Code(Z z) {
        h hVar = new h(z.Code, z.C, z.I, z.Z, z.J);
        I.Code(hVar, z.B);
        I.Code();
        return hVar.Code();
    }
}
