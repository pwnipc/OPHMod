package defpackage;

/* renamed from: bp  reason: default package */
/* compiled from: Source */
public interface bp {
    String B();

    boolean C();

    int Code();

    int Code(char c);

    int Code(String str);

    int Code(char[] cArr, int i, int i2);

    int I();

    int J();

    int Z();

    boolean a();

    boolean b();

    boolean c();

    void d();
}
