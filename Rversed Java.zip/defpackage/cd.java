package defpackage;

/* renamed from: cd  reason: default package */
/* compiled from: Source */
final class cd extends cf {
    cd(String str, int i, int i2, String str2, boolean z, int i3, int i4) {
        super(str, i, i2, str2, z, i3, i4);
    }

    /* access modifiers changed from: protected */
    public final void Code(Object[] objArr, int[] iArr) {
        super.Code(objArr, iArr);
        objArr[103] = "m";
        objArr[54] = db.j();
        objArr[92] = db.g();
        iArr[75] = "android".charAt(0);
        objArr[41] = db.i;
        iArr[74] = 109;
        iArr[101] = 115;
    }
}
