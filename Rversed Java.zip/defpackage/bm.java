package defpackage;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;

/* renamed from: bm  reason: default package */
/* compiled from: Source */
public interface bm {
    boolean B();

    void C();

    InputStream Code();

    OutputStream Code(long j);

    Enumeration Code(String str);

    String I();

    boolean J();

    long Z();
}
