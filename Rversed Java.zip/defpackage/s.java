package defpackage;

/* renamed from: s  reason: default package */
/* compiled from: Source */
final class s {
}
