package defpackage;

import android.os.Bundle;

/* renamed from: l  reason: default package */
/* compiled from: Source */
public final class l {
    private final Bundle Code;
    private final q[] I;

    public final /* bridge */ /* synthetic */ t[] I() {
        return this.I;
    }

    public final Bundle Code() {
        return this.Code;
    }
}
