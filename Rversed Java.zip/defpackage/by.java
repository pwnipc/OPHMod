package defpackage;

/* renamed from: by  reason: default package */
/* compiled from: Source */
public interface by {
    void Code();

    void Code(cs csVar);

    void Code(byte[] bArr);

    int I();

    void end();

    int read(byte[] bArr, int i, int i2);

    void setInput(byte[] bArr, int i, int i2);
}
