package defpackage;

import java.util.Map;

/* renamed from: dk  reason: default package */
/* compiled from: Source */
interface dk {
    public static final dk Code = new dk() {
        public final Map Code(Object obj) {
            return de.Code(obj);
        }

        public final Map I(Object obj) {
            return de.I(obj);
        }
    };

    Map Code(Object obj);

    Map I(Object obj);
}
