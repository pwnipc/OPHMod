package andhook.lib;

public final class BuildConfig {
    public static final String APPLICATION_ID = "andhook.lib";
    public static final String BUILD_TYPE = "debug";
    public static final boolean DEBUG = Boolean.parseBoolean("true");
    public static final String FLAVOR = "";
    public static final int VERSION_CODE = 3;
    public static final String VERSION_NAME = "3.6.0";
}
