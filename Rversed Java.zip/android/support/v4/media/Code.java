package android.support.v4.media;

import android.media.RemoteControlClient;

/* compiled from: Source */
final class Code implements RemoteControlClient.OnGetPlaybackPositionListener, RemoteControlClient.OnPlaybackPositionUpdateListener {
}
